﻿namespace WebApplication1.Authentication
{//
    public static class UserRoles
    {
        public const string User = "User";
        public const string Admin = "Admin";
    }
}
////yhjgkigjkihlaf